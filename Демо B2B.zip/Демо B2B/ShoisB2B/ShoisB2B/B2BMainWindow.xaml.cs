﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Linq;
using ShoisB2B.Data;
using ShoisB2B.Models;

namespace ShoisB2B
{
    public partial class B2BMainWindow : Window
    {
        public B2BMainWindow()
        {
            InitializeComponent();
            Loaded += B2BMainWindow_Loaded;
        }

        private void B2BMainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            LoadProducts();
        }

        private void LoadProducts()
        {
            using (var context = new B2BContext())
            {
                var products = context.Products.ToList();
                ProductsPanel.Children.Clear();

                foreach (var product in products)
                {
                    var card = CreateProductCard(product);
                    ProductsPanel.Children.Add(card);
                }

                StatusText.Text = $"Загружено {products.Count} товаров";
            }
        }

        private Border CreateProductCard(WholesaleProduct product)
        {
            var border = new Border
            {
                Width = 280,
                Height = 400,
                Margin = new Thickness(10),
                Background = Brushes.White,
                CornerRadius = new CornerRadius(10),
                BorderBrush = Brushes.LightGray,
                BorderThickness = new Thickness(1)
            };

            var stackPanel = new StackPanel { Margin = new Thickness(15) };

            // Изображение
            var imageBorder = new Border
            {
                Height = 160,
                Background = new SolidColorBrush(Color.FromRgb(245, 245, 245)),
                CornerRadius = new CornerRadius(5),
                Margin = new Thickness(0, 0, 0, 10)
            };
            var imageText = new TextBlock
            {
                Text = "👟",
                FontSize = 70,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            imageBorder.Child = imageText;
            stackPanel.Children.Add(imageBorder);

            // Название
            stackPanel.Children.Add(new TextBlock
            {
                Text = product.Name,
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 5)
            });

            // Бренд
            stackPanel.Children.Add(new TextBlock
            {
                Text = product.Brand,
                FontSize = 12,
                Foreground = Brushes.Gray,
                Margin = new Thickness(0, 0, 0, 5)
            });

            // Размер
            stackPanel.Children.Add(new TextBlock
            {
                Text = $"Размер: {product.Size}",
                FontSize = 12,
                Margin = new Thickness(0, 0, 0, 5)
            });

            // Цены
            stackPanel.Children.Add(new TextBlock
            {
                Text = $"Розница: {product.RetailPrice:N0} ₽",
                FontSize = 13,
                Foreground = Brushes.DarkGray,
                Margin = new Thickness(0, 0, 0, 3)
            });

            stackPanel.Children.Add(new TextBlock
            {
                Text = $"Опт: {product.WholesalePrice:N0} ₽",
                FontSize = 13,
                Foreground = Brushes.DarkGray,
                Margin = new Thickness(0, 0, 0, 3)
            });

            stackPanel.Children.Add(new TextBlock
            {
                Text = $"VIP: {product.VIPPrice:N0} ₽",
                FontSize = 13,
                Foreground = Brushes.DarkGray,
                Margin = new Thickness(0, 0, 0, 5)
            });

            // Наличие
            var stockColor = product.StockQuantity > 0 ? Brushes.Green : Brushes.Red;
            var stockText = product.StockQuantity > 0 ? $"На складе: {product.StockQuantity} шт." : "Нет в наличии";
            stackPanel.Children.Add(new TextBlock
            {
                Text = stockText,
                FontSize = 12,
                Foreground = stockColor,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 5)
            });

            // Мин. заказ
            stackPanel.Children.Add(new TextBlock
            {
                Text = $"Мин. заказ: {product.MinOrderQuantity} шт.",
                FontSize = 11,
                Foreground = Brushes.Gray,
                Margin = new Thickness(0, 0, 0, 10)
            });

            // Кнопка
            var button = new Button
            {
                Content = "🛒 В корзину",
                Height = 35,
                Background = new SolidColorBrush(Color.FromRgb(26, 35, 126)),
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                IsEnabled = product.StockQuantity > 0
            };
            stackPanel.Children.Add(button);

            border.Child = stackPanel;
            return border;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}