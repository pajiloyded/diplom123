﻿using System;
using System.Linq;
using ShoisB2B.Data;
using ShoisB2B.Models;

namespace ShoisB2B.Services
{
    public class SeedService
    {
        public static void Initialize(B2BContext context)
        {
            context.Database.EnsureCreated();

            if (!context.Categories.Any())
            {
                context.Categories.AddRange(
                    new WholesaleCategory { Name = "Мужская обувь", Description = "Обувь для мужчин" },
                    new WholesaleCategory { Name = "Женская обувь", Description = "Обувь для женщин" },
                    new WholesaleCategory { Name = "Детская обувь", Description = "Обувь для детей" },
                    new WholesaleCategory { Name = "Спортивная обувь", Description = "Кроссовки и кеды" }
                );
                context.SaveChanges();
            }

            if (!context.Products.Any())
            {
                var categories = context.Categories.ToList();
                context.Products.AddRange(
                    new WholesaleProduct { Name = "Туфли классические", Brand = "ECCO", Size = 42, RetailPrice = 8990, WholesalePrice = 6500, VIPPrice = 5000, StockQuantity = 100, MinOrderQuantity = 10, CategoryId = categories[0].Id },
                    new WholesaleProduct { Name = "Мокасины", Brand = "Baldinini", Size = 43, RetailPrice = 12990, WholesalePrice = 9000, VIPPrice = 7000, StockQuantity = 50, MinOrderQuantity = 5, CategoryId = categories[0].Id },
                    new WholesaleProduct { Name = "Босоножки", Brand = "Rieker", Size = 37, RetailPrice = 4590, WholesalePrice = 3000, VIPPrice = 2500, StockQuantity = 200, MinOrderQuantity = 20, CategoryId = categories[1].Id },
                    new WholesaleProduct { Name = "Кроссовки беговые", Brand = "Nike", Size = 40, RetailPrice = 7990, WholesalePrice = 5500, VIPPrice = 4500, StockQuantity = 150, MinOrderQuantity = 10, CategoryId = categories[3].Id }
                );
                context.SaveChanges();
            }

            if (!context.Companies.Any())
            {
                context.Companies.AddRange(
                    new Company { Name = "ООО ОбувьОпт", INN = "7712345678", DirectorName = "Петров П.П.", ContactPhone = "+74951234567", ContactEmail = "opt@mail.ru", CompanyType = "Оптовый", Discount = 15 },
                    new Company { Name = "ИП Иванов", INN = "5012345678", DirectorName = "Иванов И.И.", ContactPhone = "+79261234567", ContactEmail = "ivanov@mail.ru", CompanyType = "Розничный", Discount = 5 },
                    new Company { Name = "ООО VIP Обувь", INN = "7812345678", DirectorName = "Сидоров С.С.", ContactPhone = "+78121234567", ContactEmail = "vip@mail.ru", CompanyType = "VIP", Discount = 25 }
                );
                context.SaveChanges();
            }

            if (!context.Orders.Any())
            {
                var companies = context.Companies.ToList();
                context.Orders.AddRange(
                    new WholesaleOrder { CompanyId = companies[0].Id, OrderDate = DateTime.Now.AddDays(-7), TotalAmount = 150000, Status = "Выполнен", Comment = "Крупная оптовая поставка" },
                    new WholesaleOrder { CompanyId = companies[1].Id, OrderDate = DateTime.Now.AddDays(-3), TotalAmount = 45000, Status = "В обработке", Comment = "Розничный заказ" },
                    new WholesaleOrder { CompanyId = companies[2].Id, OrderDate = DateTime.Now, TotalAmount = 300000, Status = "Новый", Comment = "VIP заказ" }
                );
                context.SaveChanges();
            }

            if (!context.Users.Any())
            {
                context.Users.Add(new User
                {
                    Username = "admin",
                    Password = "admin123",
                    FullName = "Администратор",
                    Email = "admin@shoisb2b.com",
                    Role = "Admin"
                });
                context.SaveChanges();
            }
        }
    }
}