﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Linq;
using ShoisB2B.Data;
using ShoisB2B.Models;

namespace ShoisB2B
{
    public partial class MainWindowB2B : Window
    {
        public MainWindowB2B()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            LoadProducts();
        }

        private void LoadProducts()
        {
            using (var context = new B2BContext())
            {
                var products = context.Products.ToList();
                ProductsPanel.Children.Clear();

                foreach (var product in products)
                {
                    var card = CreateProductCard(product);
                    ProductsPanel.Children.Add(card);
                }

                StatusText.Text = $"Загружено {products.Count} товаров";
            }
        }

        private Border CreateProductCard(WholesaleProduct product)
        {
            var border = new Border
            {
                Width = 280,
                Height = 420,
                Margin = new Thickness(10),
                Background = Brushes.White,
                CornerRadius = new CornerRadius(10)
            };

            var stackPanel = new StackPanel { Margin = new Thickness(15) };

            var img = new Border
            {
                Height = 160,
                Background = new SolidColorBrush(Color.FromRgb(245, 245, 245)),
                CornerRadius = new CornerRadius(5),
                Margin = new Thickness(0, 0, 0, 10),
                Child = new TextBlock
                {
                    Text = "👟",
                    FontSize = 70,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                }
            };
            stackPanel.Children.Add(img);

            stackPanel.Children.Add(new TextBlock { Text = product.Name, FontSize = 16, FontWeight = FontWeights.Bold });
            stackPanel.Children.Add(new TextBlock { Text = product.Brand, FontSize = 12, Foreground = Brushes.Gray });
            stackPanel.Children.Add(new TextBlock { Text = $"Размер: {product.Size}", FontSize = 12 });
            stackPanel.Children.Add(new TextBlock { Text = $"Розница: {product.RetailPrice:N0} ₽", FontSize = 13, Foreground = Brushes.DarkGray });
            stackPanel.Children.Add(new TextBlock { Text = $"Опт: {product.WholesalePrice:N0} ₽", FontSize = 14, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Color.FromRgb(26, 35, 126)) });
            stackPanel.Children.Add(new TextBlock { Text = $"VIP: {product.VIPPrice:N0} ₽", FontSize = 13, Foreground = Brushes.Goldenrod });
            stackPanel.Children.Add(new TextBlock { Text = $"На складе: {product.StockQuantity} шт.", FontSize = 12, Foreground = Brushes.Green, Margin = new Thickness(0, 5, 0, 5) });
            stackPanel.Children.Add(new TextBlock { Text = $"Мин. заказ: {product.MinOrderQuantity} шт.", FontSize = 11, Foreground = Brushes.Gray });

            var btn = new Button
            {
                Content = "🛒 В корзину",
                Height = 35,
                Background = new SolidColorBrush(Color.FromRgb(26, 35, 126)),
                Foreground = Brushes.White,
                IsEnabled = product.StockQuantity > 0,
                Tag = product.Id
            };
            btn.Click += AddToCart_Click;
            stackPanel.Children.Add(btn);

            border.Child = stackPanel;
            return border;
        }

        private void AddToCart_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;
            var productId = (int)btn.Tag;

            // Здесь будет логика добавления в корзину
            MessageBox.Show($"Товар ID:{productId} добавлен в корзину!", "B2B Заказ",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void CreateOrder_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new B2BContext())
            {
                // Создаем тестовую компанию если нет
                if (!context.Companies.Any())
                {
                    var company = new Company
                    {
                        Name = "ООО Тестовая компания",
                        INN = "1234567890",
                        DirectorName = "Иванов И.И.",
                        ContactPhone = "+79991234567",
                        ContactEmail = "test@mail.ru",
                        CompanyType = "Оптовый",
                        Discount = 10
                    };
                    context.Companies.Add(company);
                    context.SaveChanges();
                }

                var firstCompany = context.Companies.First();
                var order = new WholesaleOrder
                {
                    CompanyId = firstCompany.Id,
                    OrderDate = System.DateTime.Now,
                    TotalAmount = 50000,
                    Status = "Новый",
                    Comment = "Тестовый заказ"
                };
                context.Orders.Add(order);
                context.SaveChanges();

                LoadOrders();
                StatusText.Text = "Заказ создан!";
            }
        }

        private void AddCompany_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new B2BContext())
            {
                var company = new Company
                {
                    Name = "Новая компания " + System.DateTime.Now.Second,
                    INN = "INN" + System.DateTime.Now.Ticks.ToString().Substring(0, 10),
                    DirectorName = "Директор",
                    ContactPhone = "+79990000000",
                    ContactEmail = "new@mail.ru",
                    CompanyType = "Розничный",
                    Discount = 5
                };
                context.Companies.Add(company);
                context.SaveChanges();

                LoadCompanies();
                StatusText.Text = "Компания добавлена!";
            }
        }

        private void LoadOrders()
        {
            using (var context = new B2BContext())
            {
                var orders = context.Orders.ToList();
                OrdersGrid.ItemsSource = orders;
                StatusText.Text = $"Заказов: {orders.Count}";
            }
        }

        private void LoadCompanies()
        {
            using (var context = new B2BContext())
            {
                var companies = context.Companies.ToList();
                CompaniesGrid.ItemsSource = companies;
                StatusText.Text = $"Компаний: {companies.Count}";
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}