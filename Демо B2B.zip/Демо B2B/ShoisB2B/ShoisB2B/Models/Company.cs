﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ShoisB2B.Models
{
    public class Company
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string INN { get; set; } = string.Empty;
        public string DirectorName { get; set; } = string.Empty;
        public string ContactPhone { get; set; } = string.Empty;
        public string ContactEmail { get; set; } = string.Empty;
        public string CompanyType { get; set; } = "Розничный";
        public decimal Discount { get; set; } = 0;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public bool IsActive { get; set; } = true;
    }
}