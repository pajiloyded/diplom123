﻿using System.ComponentModel.DataAnnotations;

namespace ShoisB2B.Models
{
    public class WholesaleCategory
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }
}