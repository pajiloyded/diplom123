﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ShoisB2B.Models
{
    public class WholesaleProduct
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Brand { get; set; } = string.Empty;
        public double Size { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal RetailPrice { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal WholesalePrice { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal VIPPrice { get; set; }

        public int StockQuantity { get; set; }
        public int MinOrderQuantity { get; set; } = 1;
        public int CategoryId { get; set; }
        public string Description { get; set; } = string.Empty;

        [ForeignKey("CategoryId")]
        public WholesaleCategory? Category { get; set; }
    }
}