﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ShoisB2B.Models
{
    public class WholesaleOrder
    {
        [Key]
        public int Id { get; set; }
        public int CompanyId { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.Now;

        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalAmount { get; set; }

        public string Status { get; set; } = "Новый";
        public string Comment { get; set; } = string.Empty;

        [ForeignKey("CompanyId")]
        public Company? Company { get; set; }
    }
}