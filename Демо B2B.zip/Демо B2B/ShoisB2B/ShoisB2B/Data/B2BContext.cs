﻿using Microsoft.EntityFrameworkCore;
using ShoisB2B.Models;

namespace ShoisB2B.Data
{
    public class B2BContext : DbContext
    {
        public DbSet<Company> Companies { get; set; }
        public DbSet<WholesaleProduct> Products { get; set; }
        public DbSet<WholesaleCategory> Categories { get; set; }
        public DbSet<WholesaleOrder> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=ShoisB2B.db");
        }
    }
}