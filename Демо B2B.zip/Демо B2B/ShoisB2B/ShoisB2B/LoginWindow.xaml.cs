﻿using System.Windows;
using System.Linq;
using ShoisB2B.Data;
using ShoisB2B.Services;

namespace ShoisB2B
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();

            using (var context = new B2BContext())
            {
                SeedService.Initialize(context);
            }
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            ErrorText.Visibility = Visibility.Collapsed;

            var username = UsernameTextBox.Text.Trim();
            var password = PasswordBox.Password;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                ErrorText.Text = "Заполните все поля!";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            using (var context = new B2BContext())
            {
                var user = context.Users.FirstOrDefault(u => u.Username == username && u.Password == password);

                if (user != null)
                {
                    var mainWindow = new MainWindowB2B();
                    mainWindow.Show();
                    Close();
                }
                else
                {
                    ErrorText.Text = "Неверный логин или пароль!";
                    ErrorText.Visibility = Visibility.Visible;
                }
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}