﻿using Microsoft.EntityFrameworkCore;
using Shois.Models;

namespace Shois.Services
{
    public class AuthService
    {
        private readonly ShoisContext _context;

        public AuthService(ShoisContext context)
        {
            _context = context;
        }

        public async Task<User> LoginAsync(string username, string password)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.Username == username && u.Password == password);
        }

        public async Task<bool> RegisterAsync(string username, string password, string fullName, string email)
        {
            var existingUser = await _context.Users
                .FirstOrDefaultAsync(u => u.Username == username);

            if (existingUser != null)
                return false;

            var user = new User
            {
                Username = username,
                Password = password,
                FullName = fullName,
                Email = email,
                Role = "User",
                CreatedAt = DateTime.Now
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> IsAdminAsync(string username)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Username == username);
            return user?.Role == "Admin";
        }
    }
}