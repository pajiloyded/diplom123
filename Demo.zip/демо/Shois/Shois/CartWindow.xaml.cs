﻿using Shois.Models;
using System.Windows;

namespace Shois
{
    public partial class CartWindow : Window
    {
        private List<CartItem> _cart;
        private ShoisContext _context;

        public CartWindow(List<CartItem> cart, ShoisContext context)
        {
            InitializeComponent();
            _cart = cart;
            _context = context;
            Loaded += CartWindow_Loaded;
        }

        private void CartWindow_Loaded(object sender, RoutedEventArgs e)
        {
            CartGrid.ItemsSource = _cart;
            UpdateTotal();
        }

        private void UpdateTotal()
        {
            var total = _cart.Sum(c => c.Total);
            TotalText.Text = $"Итого: {total:N0} ₽";
        }

        private void ContinueButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void CheckoutButton_Click(object sender, RoutedEventArgs e)
        {
            if (_cart == null || _cart.Count == 0)
            {
                MessageBox.Show("Корзина пуста!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Проверяем, что все товары еще есть в наличии
            foreach (var item in _cart)
            {
                var shoeInDb = _context.Shoes.Find(item.Shoe.Id);
                if (shoeInDb == null || shoeInDb.Quantity < item.Quantity)
                {
                    MessageBox.Show($"Товар \"{item.Shoe.Name}\" недоступен в нужном количестве!\n" +
                                  $"Доступно: {shoeInDb?.Quantity ?? 0} шт.\n" +
                                  $"В корзине: {item.Quantity} шт.",
                                  "Ошибка",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Warning);
                    return;
                }
            }

            var checkoutWindow = new CheckoutWindow(_cart, _context);
            checkoutWindow.Owner = this;

            if (checkoutWindow.ShowDialog() == true)
            {
                MessageBox.Show("✅ Заказ успешно оформлен!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                _cart.Clear();
                CartGrid.ItemsSource = null;
                UpdateTotal();
            }
        }
    }
}