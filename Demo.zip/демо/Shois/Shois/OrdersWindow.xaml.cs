﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;
using Shois.Models;

namespace Shois
{
    public partial class OrdersWindow : Window
    {
        private ShoisContext _context;
        private string _email;

        public OrdersWindow(ShoisContext context, string email)
        {
            InitializeComponent();
            _context = context;
            _email = email;
            Loaded += OrdersWindow_Loaded;
        }

        private async void OrdersWindow_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                var customer = await _context.Customers
                    .FirstOrDefaultAsync(c => c.Email == _email);

                if (customer == null)
                {
                    MessageBox.Show("Заказы не найдены", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                    Close();
                    return;
                }

                var orders = await _context.Orders
                    .Where(o => o.CustomerId == customer.Id)
                    .OrderByDescending(o => o.OrderDate)
                    .ToListAsync();

                OrdersGrid.ItemsSource = orders;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void ShowDetailsButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var orderId = (int)button.Tag;

            var items = await _context.OrderItems
                .Include(oi => oi.Shoe)
                .Where(oi => oi.OrderId == orderId)
                .ToListAsync();

            var details = string.Join("\n", items.Select(i =>
                $"{i.Shoe.Name} - {i.Quantity} шт. x {i.Price:N0} ₽ = {i.Quantity * i.Price:N0} ₽"));

            MessageBox.Show(details, $"Состав заказа №{orderId}", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}