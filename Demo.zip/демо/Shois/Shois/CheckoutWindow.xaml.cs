﻿using System.Windows;
using Microsoft.EntityFrameworkCore;
using Shois.Models;

namespace Shois
{
    public partial class CheckoutWindow : Window
    {
        private List<CartItem> _cart;
        private ShoisContext _context;

        public CheckoutWindow(List<CartItem> cart, ShoisContext context)
        {
            InitializeComponent();
            _cart = cart;
            _context = context;
            Loaded += CheckoutWindow_Loaded;
        }

        private void CheckoutWindow_Loaded(object sender, RoutedEventArgs e)
        {
            TotalText.Text = $"Итого: {_cart.Sum(c => c.Total):N0} ₽";
        }

        private async void ConfirmButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(FullNameTextBox.Text))
            {
                MessageBox.Show("Введите ФИО!");
                return;
            }

            if (string.IsNullOrWhiteSpace(EmailTextBox.Text))
            {
                MessageBox.Show("Введите Email!");
                return;
            }

            try
            {
                // Ищем или создаем клиента
                var customer = await _context.Customers
                    .FirstOrDefaultAsync(c => c.Email == EmailTextBox.Text);

                if (customer == null)
                {
                    customer = new Customer
                    {
                        FullName = FullNameTextBox.Text,
                        Phone = PhoneTextBox.Text,
                        Email = EmailTextBox.Text,
                        Address = AddressTextBox.Text
                    };
                    _context.Customers.Add(customer);
                    await _context.SaveChangesAsync();
                }

                // Создаем заказ
                var order = new Order
                {
                    CustomerId = customer.Id,
                    OrderDate = DateTime.Now,
                    TotalAmount = _cart.Sum(c => c.Total),
                    Status = "Новый"
                };
                _context.Orders.Add(order);
                await _context.SaveChangesAsync();

                // Добавляем позиции заказа и ОБНОВЛЯЕМ КОЛИЧЕСТВО ТОВАРОВ
                foreach (var item in _cart)
                {
                    // Добавляем позицию в заказ
                    _context.OrderItems.Add(new OrderItem
                    {
                        OrderId = order.Id,
                        ShoeId = item.Shoe.Id,
                        Quantity = item.Quantity,
                        Price = item.Shoe.Price
                    });

                    // НАЙДИ ТОВАР В БАЗЕ И УМЕНЬШИ КОЛИЧЕСТВО
                    var shoeInDb = await _context.Shoes.FindAsync(item.Shoe.Id);
                    if (shoeInDb != null)
                    {
                        shoeInDb.Quantity -= item.Quantity;

                        // Проверка, чтобы количество не стало отрицательным
                        if (shoeInDb.Quantity < 0)
                        {
                            shoeInDb.Quantity = 0;
                        }

                        _context.Shoes.Update(shoeInDb);
                    }
                }

                // Сохраняем все изменения
                await _context.SaveChangesAsync();

                MessageBox.Show($"✅ Заказ №{order.Id} успешно оформлен!\n\n" +
                              $"Сумма: {order.TotalAmount:N0} ₽\n" +
                              $"Статус: {order.Status}\n" +
                              $"Количество позиций: {_cart.Count}\n" +
                              $"Всего товаров: {_cart.Sum(c => c.Quantity)} шт.",
                              "Заказ оформлен",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при оформлении заказа:\n{ex.Message}\n\n" +
                              $"Внутренняя ошибка: {ex.InnerException?.Message}",
                              "Ошибка",
                              MessageBoxButton.OK,
                              MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}