﻿using System.Windows;
using Microsoft.EntityFrameworkCore;
using Shois.Models;

namespace Shois
{
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }

        private async void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            ErrorText.Visibility = Visibility.Collapsed;

            var fullName = FullNameTextBox.Text.Trim();
            var email = EmailTextBox.Text.Trim();
            var username = UsernameTextBox.Text.Trim();
            var password = PasswordBox.Password;
            var confirmPassword = ConfirmPasswordBox.Password;

            if (string.IsNullOrWhiteSpace(fullName) ||
                string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrWhiteSpace(password))
            {
                ErrorText.Text = "Заполните все поля!";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            if (password != confirmPassword)
            {
                ErrorText.Text = "Пароли не совпадают!";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            if (password.Length < 3)
            {
                ErrorText.Text = "Пароль должен быть минимум 3 символа!";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            try
            {
                var optionsBuilder = new DbContextOptionsBuilder<ShoisContext>();
                optionsBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=Shois;Trusted_Connection=True;TrustServerCertificate=True;");

                using (var context = new ShoisContext(optionsBuilder.Options))
                {
                    // Проверяем, существует ли пользователь
                    var existingUser = await context.Users
                        .FirstOrDefaultAsync(u => u.Username == username);

                    if (existingUser != null)
                    {
                        ErrorText.Text = "Пользователь с таким логином уже существует!";
                        ErrorText.Visibility = Visibility.Visible;
                        return;
                    }

                    // Создаем нового пользователя
                    var user = new User
                    {
                        Username = username,
                        Password = password,
                        FullName = fullName,
                        Email = email,
                        Role = "User",
                        CreatedAt = DateTime.Now
                    };

                    context.Users.Add(user);
                    await context.SaveChangesAsync();

                    MessageBox.Show("Регистрация успешна! Теперь войдите в систему.",
                        "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                    var loginWindow = new LoginWindow();
                    loginWindow.Show();
                    Close();
                }
            }
            catch (Exception ex)
            {
                ErrorText.Text = $"Ошибка: {ex.Message}";
                ErrorText.Visibility = Visibility.Visible;
            }
        }

        private void LoginLink_Click(object sender, RoutedEventArgs e)
        {
            var loginWindow = new LoginWindow();
            loginWindow.Show();
            Close();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}