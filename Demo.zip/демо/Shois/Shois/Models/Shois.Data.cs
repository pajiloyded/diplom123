﻿using Microsoft.EntityFrameworkCore;
using Shois.Models;

namespace Shois.Data
{
    public class ShoeRepository
    {
        private readonly ShoisContext _context;

        public ShoeRepository(ShoisContext context)
        {
            _context = context;
        }

        public async Task<List<Shoe>> GetAllShoesAsync()
        {
            return await _context.Shoes.Include(s => s.Category).ToListAsync();
        }

        public async Task<Shoe> GetShoeByIdAsync(int id)
        {
            return await _context.Shoes.Include(s => s.Category).FirstOrDefaultAsync(s => s.Id == id);
        }

        public async Task AddShoeAsync(Shoe shoe)
        {
            await _context.Shoes.AddAsync(shoe);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateShoeAsync(Shoe shoe)
        {
            _context.Shoes.Update(shoe);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteShoeAsync(int id)
        {
            var shoe = await _context.Shoes.FindAsync(id);
            if (shoe != null)
            {
                _context.Shoes.Remove(shoe);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<List<Shoe>> SearchShoesAsync(string searchText)
        {
            return await _context.Shoes.Include(s => s.Category)
                .Where(s => s.Name.Contains(searchText) || s.Brand.Contains(searchText))
                .ToListAsync();
        }

        public async Task<List<Shoe>> GetShoesByCategoryAsync(int categoryId)
        {
            return await _context.Shoes.Include(s => s.Category)
                .Where(s => s.CategoryId == categoryId).ToListAsync();
        }

        public async Task<List<Category>> GetAllCategoriesAsync()
        {
            return await _context.Categories.ToListAsync();
        }

        public async Task<int> GetModelsCountAsync()
        {
            return await _context.Shoes.CountAsync();
        }

        public async Task<int> GetTotalShoesCountAsync()
        {
            return await _context.Shoes.SumAsync(s => s.Quantity);
        }

        public async Task<decimal> GetTotalValueAsync()
        {
            return await _context.Shoes.SumAsync(s => s.Price * s.Quantity);
        }
    }
}