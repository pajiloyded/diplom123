﻿using System.Windows;
using Microsoft.EntityFrameworkCore;
using Shois.Models;

namespace Shois
{
    public partial class ShoeDialog : Window
    {
        private readonly ShoisContext _context;
        public Shoe Shoe { get; private set; }

        public ShoeDialog(ShoisContext context, Shoe shoe = null)
        {
            InitializeComponent();
            _context = context;
            Loaded += ShoeDialog_Loaded;

            if (shoe != null)
            {
                Shoe = shoe;
                TitleText.Text = "Редактирование обуви";
                Title = "Редактирование обуви";
                LoadShoeData();
            }
            else
            {
                Shoe = new Shoe();
            }
        }

        private async void ShoeDialog_Loaded(object sender, RoutedEventArgs e)
        {
            var categories = await _context.Categories.ToListAsync();
            CategoryComboBox.ItemsSource = categories;
            CategoryComboBox.DisplayMemberPath = "Name";
            CategoryComboBox.SelectedValuePath = "Id";

            if (Shoe.CategoryId != null)
                CategoryComboBox.SelectedValue = Shoe.CategoryId;
        }

        private void LoadShoeData()
        {
            NameTextBox.Text = Shoe.Name;
            BrandTextBox.Text = Shoe.Brand;
            SizeTextBox.Text = Shoe.Size.ToString();
            PriceTextBox.Text = Shoe.Price.ToString();
            QuantityTextBox.Text = Shoe.Quantity.ToString();
            DescriptionTextBox.Text = Shoe.Description;
            if (Shoe.CategoryId != null)
                CategoryComboBox.SelectedValue = Shoe.CategoryId;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NameTextBox.Text))
            { MessageBox.Show("Введите название!"); return; }
            if (string.IsNullOrWhiteSpace(BrandTextBox.Text))
            { MessageBox.Show("Введите бренд!"); return; }
            if (!double.TryParse(SizeTextBox.Text, out double size) || size <= 0)
            { MessageBox.Show("Введите корректный размер!"); return; }
            if (!decimal.TryParse(PriceTextBox.Text, out decimal price) || price <= 0)
            { MessageBox.Show("Введите корректную цену!"); return; }
            if (!int.TryParse(QuantityTextBox.Text, out int qty) || qty < 0)
            { MessageBox.Show("Введите корректное количество!"); return; }
            if (CategoryComboBox.SelectedValue == null)
            { MessageBox.Show("Выберите категорию!"); return; }

            Shoe.Name = NameTextBox.Text.Trim();
            Shoe.Brand = BrandTextBox.Text.Trim();
            Shoe.Size = size;
            Shoe.Price = price;
            Shoe.Quantity = qty;
            Shoe.Description = DescriptionTextBox.Text?.Trim();
            Shoe.CategoryId = (int)CategoryComboBox.SelectedValue;

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}