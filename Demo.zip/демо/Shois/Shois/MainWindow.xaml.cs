﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;
using Shois.Data;
using Shois.Models;

namespace Shois
{
    public partial class MainWindow : Window
    {
        private ShoeRepository _repository;
        private ShoisContext _context;

        public MainWindow()
        {
            try
            {
                InitializeComponent();
                InitializeDatabase();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка инициализации: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void InitializeDatabase()
        {
            try
            {
                var optionsBuilder = new DbContextOptionsBuilder<ShoisContext>();
                optionsBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=Shois;Trusted_Connection=True;TrustServerCertificate=True;");
                _context = new ShoisContext(optionsBuilder.Options);
                _repository = new ShoeRepository(_context);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к БД: {ex.Message}\n\nПроверь строку подключения в коде!",
                    "Ошибка БД", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (_repository == null)
            {
                MessageBox.Show("Нет подключения к базе данных!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            await LoadData();
            await LoadCategories();
        }

        private void OpenShopButton_Click(object sender, RoutedEventArgs e)
        {
            var shopWindow = new ShopWindow();
            shopWindow.Show();
        }

        private async Task LoadData()
        {
            try
            {
                UpdateStatus("Загрузка данных...");
                var shoes = await _repository.GetAllShoesAsync();
                ShoesGrid.ItemsSource = shoes;
                UpdateStats();
                UpdateStatus($"Загружено {shoes.Count} моделей");
            }
            catch (Exception ex)
            {
                UpdateStatus("Ошибка загрузки");
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task LoadCategories()
        {
            try
            {
                var categories = await _repository.GetAllCategoriesAsync();
                CategoryFilter.Items.Clear();
                CategoryFilter.Items.Add(new ComboBoxItem { Content = "Все категории", IsSelected = true });
                foreach (var category in categories)
                {
                    CategoryFilter.Items.Add(new ComboBoxItem { Content = category.Name, Tag = category.Id });
                }
            }
            catch { }
        }

        private async void UpdateStats()
        {
            try
            {
                var modelsCount = await _repository.GetModelsCountAsync();
                var totalQuantity = await _repository.GetTotalShoesCountAsync();
                var totalValue = await _repository.GetTotalValueAsync();

                if (StatsText != null)
                    StatsText.Text = $"Моделей: {modelsCount} | Пар: {totalQuantity} | На сумму: {totalValue:N0} руб.";
            }
            catch { }
        }

        private void UpdateStatus(string text)
        {
            if (StatusText != null)
                StatusText.Text = text;
        }

        private async void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_repository == null) return;

            if (string.IsNullOrWhiteSpace(SearchTextBox.Text))
                await LoadData();
            else
            {
                var shoes = await _repository.SearchShoesAsync(SearchTextBox.Text);
                ShoesGrid.ItemsSource = shoes;
            }
        }

        private async void CategoryFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_repository == null) return;

            if (CategoryFilter.SelectedItem is ComboBoxItem item && item.Tag != null)
            {
                var categoryId = (int)item.Tag;
                var shoes = await _repository.GetShoesByCategoryAsync(categoryId);
                ShoesGrid.ItemsSource = shoes;
            }
            else
                await LoadData();
        }

        private async void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            if (SearchTextBox != null)
                SearchTextBox.Text = "";

            if (CategoryFilter != null)
                CategoryFilter.SelectedIndex = 0;

            await LoadData();
            await LoadCategories();

            UpdateStatus("Данные обновлены");
        }

        private async void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (_context == null) return;

            var dialog = new ShoeDialog(_context);
            if (dialog.ShowDialog() == true)
            {
                await _repository.AddShoeAsync(dialog.Shoe);
                await LoadData();
                UpdateStatus("Товар добавлен");
            }
        }

        private async void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (_repository == null) return;

            var button = sender as Button;
            var shoeId = (int)button.Tag;
            var shoe = await _repository.GetShoeByIdAsync(shoeId);

            if (shoe != null)
            {
                var dialog = new ShoeDialog(_context, shoe);
                if (dialog.ShowDialog() == true)
                {
                    await _repository.UpdateShoeAsync(shoe);
                    await LoadData();
                    UpdateStatus("Товар обновлен");
                }
            }
        }

        private async void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (_repository == null) return;

            var button = sender as Button;
            var shoeId = (int)button.Tag;

            var result = MessageBox.Show("Удалить этот товар?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                await _repository.DeleteShoeAsync(shoeId);
                await LoadData();
                UpdateStatus("Товар удален");
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            _context?.Dispose();
        }
    }
}