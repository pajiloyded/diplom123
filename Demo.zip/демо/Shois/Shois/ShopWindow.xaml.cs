﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.EntityFrameworkCore;
using Shois.Data;
using Shois.Models;

namespace Shois
{
    public class CartItem
    {
        public Shoe Shoe { get; set; }
        public int Quantity { get; set; }
        public decimal Total => Shoe.Price * Quantity;
    }

    public partial class ShopWindow : Window
    {
        private ShoeRepository _repository;
        private ShoisContext _context;
        private List<Shoe> _allShoes;
        private List<CartItem> _cart = new List<CartItem>();

        public ShopWindow()
        {
            InitializeComponent();

            var optionsBuilder = new DbContextOptionsBuilder<ShoisContext>();
            optionsBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=Shois;Trusted_Connection=True;TrustServerCertificate=True;");
            _context = new ShoisContext(optionsBuilder.Options);
            _repository = new ShoeRepository(_context);

            Loaded += ShopWindow_Loaded;
        }

        private async void ShopWindow_Loaded(object sender, RoutedEventArgs e)
        {
            await LoadProducts();
            await LoadCategories();
        }

        private async Task LoadProducts()
        {
            try
            {
                _allShoes = await _repository.GetAllShoesAsync();
                DisplayProducts(_allShoes);
                UpdateCartStatus();
                StatusText.Text = $"Найдено {_allShoes.Count} товаров";
            }
            catch (Exception ex)
            {
                StatusText.Text = "Ошибка загрузки";
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task LoadCategories()
        {
            var categories = await _repository.GetAllCategoriesAsync();
            CategoryFilter.Items.Clear();
            CategoryFilter.Items.Add(new ComboBoxItem { Content = "Все категории", IsSelected = true });
            foreach (var category in categories)
            {
                CategoryFilter.Items.Add(new ComboBoxItem { Content = category.Name, Tag = category.Id });
            }
        }

        private void DisplayProducts(List<Shoe> shoes)
        {
            ProductsPanel.Children.Clear();

            foreach (var shoe in shoes)
            {
                var card = CreateProductCard(shoe);
                ProductsPanel.Children.Add(card);
            }
        }

        private Border CreateProductCard(Shoe shoe)
        {
            var border = new Border
            {
                Width = 250,
                Height = 380,
                Margin = new Thickness(10),
                Background = Brushes.White,
                CornerRadius = new CornerRadius(10),
                BorderBrush = Brushes.LightGray,
                BorderThickness = new Thickness(1)
            };

            var stackPanel = new StackPanel { Margin = new Thickness(15) };

            var imageBorder = new Border
            {
                Height = 180,
                Background = new SolidColorBrush(Color.FromRgb(245, 245, 245)),
                CornerRadius = new CornerRadius(5),
                Margin = new Thickness(0, 0, 0, 10)
            };
            var imageText = new TextBlock
            {
                Text = "👟",
                FontSize = 80,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            imageBorder.Child = imageText;
            stackPanel.Children.Add(imageBorder);

            stackPanel.Children.Add(new TextBlock
            {
                Text = shoe.Name,
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                TextTrimming = TextTrimming.CharacterEllipsis,
                Margin = new Thickness(0, 0, 0, 5)
            });

            stackPanel.Children.Add(new TextBlock
            {
                Text = shoe.Brand,
                FontSize = 12,
                Foreground = Brushes.Gray,
                Margin = new Thickness(0, 0, 0, 5)
            });

            stackPanel.Children.Add(new TextBlock
            {
                Text = $"Размер: {shoe.Size}",
                FontSize = 12,
                Margin = new Thickness(0, 0, 0, 5)
            });

            stackPanel.Children.Add(new TextBlock
            {
                Text = $"{shoe.Price:N0} ₽",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(98, 0, 238)),
                Margin = new Thickness(0, 5, 0, 10)
            });

            var stockColor = shoe.Quantity > 0 ? Brushes.Green : Brushes.Red;
            var stockText = shoe.Quantity > 0 ? $"В наличии: {shoe.Quantity} шт." : "Нет в наличии";
            stackPanel.Children.Add(new TextBlock
            {
                Text = stockText,
                FontSize = 11,
                Foreground = stockColor,
                Margin = new Thickness(0, 0, 0, 10)
            });

            var button = new Button
            {
                Content = "🛒 В корзину",
                Height = 35,
                Background = new SolidColorBrush(Color.FromRgb(98, 0, 238)),
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                IsEnabled = shoe.Quantity > 0,
                Tag = shoe.Id
            };
            button.Click += AddToCartButton_Click;
            stackPanel.Children.Add(button);

            border.Child = stackPanel;
            return border;
        }

        private void AddToCartButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var shoeId = (int)button.Tag;
            var shoe = _allShoes.FirstOrDefault(s => s.Id == shoeId);

            if (shoe == null) return;

            var existingItem = _cart.FirstOrDefault(c => c.Shoe.Id == shoeId);
            if (existingItem != null)
                existingItem.Quantity++;
            else
                _cart.Add(new CartItem { Shoe = shoe, Quantity = 1 });

            UpdateCartStatus();
            MessageBox.Show($"{shoe.Name} добавлен в корзину!", "Успешно",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void UpdateCartStatus()
        {
            var totalItems = _cart.Sum(c => c.Quantity);
            var totalSum = _cart.Sum(c => c.Total);
            StatusText.Text = $"🛒 В корзине: {totalItems} шт. на сумму {totalSum:N0} ₽";
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_allShoes == null) return;

            if (string.IsNullOrWhiteSpace(SearchTextBox.Text))
                DisplayProducts(_allShoes);
            else
            {
                var filtered = _allShoes
                    .Where(s => s.Name.Contains(SearchTextBox.Text, StringComparison.OrdinalIgnoreCase) ||
                               s.Brand.Contains(SearchTextBox.Text, StringComparison.OrdinalIgnoreCase))
                    .ToList();
                DisplayProducts(filtered);
            }
        }

        private void CategoryFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_allShoes == null) return;

            if (CategoryFilter.SelectedItem is ComboBoxItem item && item.Tag != null)
            {
                var categoryId = (int)item.Tag;
                var filtered = _allShoes.Where(s => s.CategoryId == categoryId).ToList();
                DisplayProducts(filtered);
            }
            else
                DisplayProducts(_allShoes);
        }

        private async void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            SearchTextBox.Text = "";
            CategoryFilter.SelectedIndex = 0;
            await LoadProducts();
            StatusText.Text = "Список обновлен";
        }

        private void CartButton_Click(object sender, RoutedEventArgs e)
        {
            if (_cart.Count == 0)
            {
                MessageBox.Show("Корзина пуста! Добавьте товары.", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var cartWindow = new CartWindow(_cart, _context);
            cartWindow.Owner = this;
            cartWindow.ShowDialog();

            UpdateCartStatus();
            LoadProducts();
        }

        private void OrdersButton_Click(object sender, RoutedEventArgs e)
        {
            var email = Microsoft.VisualBasic.Interaction.InputBox(
                "Введите email для поиска заказов:",
                "Поиск заказов", "");

            if (!string.IsNullOrWhiteSpace(email))
            {
                var ordersWindow = new OrdersWindow(_context, email);
                ordersWindow.Owner = this;
                ordersWindow.ShowDialog();
            }
        }

        private void AdminButton_Click(object sender, RoutedEventArgs e)
        {
            var password = Microsoft.VisualBasic.Interaction.InputBox(
                "Введите пароль администратора:",
                "Доступ к админ-панели",
                "",
                -1, -1);

            if (password == "admin123")
            {
                var adminWindow = new MainWindow();
                adminWindow.Show();
            }
            else if (!string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Неверный пароль!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}