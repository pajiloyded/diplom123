﻿using System.Windows;
using Microsoft.EntityFrameworkCore;
using Shois.Models;

namespace Shois
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            ErrorText.Visibility = Visibility.Collapsed;

            var username = UsernameTextBox.Text.Trim();
            var password = PasswordBox.Password;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                ErrorText.Text = "Заполните все поля!";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            try
            {
                var optionsBuilder = new DbContextOptionsBuilder<ShoisContext>();
                optionsBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=Shois;Trusted_Connection=True;TrustServerCertificate=True;");

                using (var context = new ShoisContext(optionsBuilder.Options))
                {
                    var user = context.Users.FirstOrDefault(u => u.Username == username && u.Password == password);

                    if (user != null)
                    {
                        if (user.Role == "Admin")
                        {
                            var adminWindow = new MainWindow();
                            adminWindow.Show();
                        }
                        else
                        {
                            var shopWindow = new ShopWindow();
                            shopWindow.Show();
                        }

                        Close();
                    }
                    else
                    {
                        ErrorText.Text = "Неверный логин или пароль!";
                        ErrorText.Visibility = Visibility.Visible;
                    }
                }
            }
            catch (Exception ex)
            {
                // Запасной вход если БД недоступна
                if (username == "admin" && password == "admin123")
                {
                    var adminWindow = new MainWindow();
                    adminWindow.Show();
                    Close();
                    return;
                }

                ErrorText.Text = $"Ошибка: {ex.Message}";
                ErrorText.Visibility = Visibility.Visible;
            }
        }

        private void RegisterLink_Click(object sender, RoutedEventArgs e)
        {
            var registerWindow = new RegisterWindow();
            registerWindow.Show();
            Close();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}