﻿using ClothingShopWPF;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using бд.Models;

namespace ClothingShop
{
    public partial class AdminMainPanel : Window
    {
        private int userId;
        private string userRole;

        public AdminMainPanel(int userId, string userRole)
        {
            InitializeComponent();
            this.userId = userId;
            this.userRole = userRole;
            ShowOrders();
        }

        private void ShowOrders()
        {
            OrdersPanel.Visibility = Visibility.Visible;
            ProductsPanel.Visibility = Visibility.Collapsed;
            UsersPanel.Visibility = Visibility.Collapsed;
            LoadOrders();
        }

        private void ShowProducts()
        {
            OrdersPanel.Visibility = Visibility.Collapsed;
            ProductsPanel.Visibility = Visibility.Visible;
            UsersPanel.Visibility = Visibility.Collapsed;
            LoadProducts();
        }

        private void ShowUsers()
        {
            OrdersPanel.Visibility = Visibility.Collapsed;
            ProductsPanel.Visibility = Visibility.Collapsed;
            UsersPanel.Visibility = Visibility.Visible;
            LoadUsers();
        }

        private void LoadOrders()
        {
            using (var context = new ClothingShopContext())
            {
                dgOrders.ItemsSource = context.Orders.ToList();
            }
        }

        private void Admin_Orders_Click(object sender, RoutedEventArgs e)
        {
            ShowOrders();
        }

        private void EditOrderStatus_Click(object sender, RoutedEventArgs e)
        {
            if (dgOrders.SelectedItem is Order order)
            {
                Window statusWindow = new Window
                {
                    Title = "Изменить статус заказа",
                    Width = 300,
                    Height = 200,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    ResizeMode = ResizeMode.NoResize
                };

                Grid grid = new Grid();
                grid.Margin = new Thickness(20);
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

                ComboBox cmbStatus = new ComboBox { Margin = new Thickness(0, 0, 0, 10) };
                cmbStatus.ItemsSource = new[] { "Новый", "В обработке", "Отправлен", "Выполнен", "Отменен" };
                cmbStatus.SelectedItem = order.Status;

                StackPanel buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
                Button btnSave = new Button { Content = "Сохранить", Width = 80, Height = 30, Margin = new Thickness(0, 0, 10, 0) };
                Button btnCancel = new Button { Content = "Отмена", Width = 80, Height = 30 };
                buttons.Children.Add(btnSave);
                buttons.Children.Add(btnCancel);

                grid.Children.Add(cmbStatus);
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 0);
                grid.Children.Add(buttons);
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 1);

                statusWindow.Content = grid;
                btnCancel.Click += (s, e) => statusWindow.Close();

                btnSave.Click += (s, e) =>
                {
                    order.Status = cmbStatus.SelectedItem?.ToString() ?? "Новый";
                    using (var context = new ClothingShopContext())
                    {
                        context.Orders.Update(order);
                        context.SaveChanges();
                    }
                    statusWindow.Close();
                    LoadOrders();
                    MessageBox.Show("Статус заказа обновлён!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                };

                statusWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Выберите заказ для редактирования", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DeleteOrder_Click(object sender, RoutedEventArgs e)
        {
            if (dgOrders.SelectedItem is Order order)
            {
                var result = MessageBox.Show($"Удалить заказ №{order.Id}?",
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    using (var context = new ClothingShopContext())
                    {
                        var orderItems = context.OrderItems.Where(oi => oi.OrderId == order.Id);
                        context.OrderItems.RemoveRange(orderItems);
                        context.Orders.Remove(order);
                        context.SaveChanges();
                    }
                    LoadOrders();
                    MessageBox.Show("Заказ удалён!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Выберите заказ для удаления", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void LoadProducts()
        {
            using (var context = new ClothingShopContext())
            {
                dgProducts.ItemsSource = context.Products.ToList();
            }
        }

        private void Admin_Products_Click(object sender, RoutedEventArgs e)
        {
            ShowProducts();
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            Window addProductWindow = new Window
            {
                Title = "Добавление товара",
                Width = 400,
                Height = 350,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize
            };

            Grid grid = new Grid();
            grid.Margin = new Thickness(20);
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            TextBox txtName = new TextBox { Margin = new Thickness(0, 0, 0, 10) };
            ComboBox cmbCategory = new ComboBox { Margin = new Thickness(0, 0, 0, 10) };
            TextBox txtSize = new TextBox { Margin = new Thickness(0, 0, 0, 10) };
            TextBox txtPrice = new TextBox { Margin = new Thickness(0, 0, 0, 10) };
            TextBox txtStock = new TextBox { Margin = new Thickness(0, 0, 0, 10) };

            using (var context = new ClothingShopContext())
            {
                cmbCategory.ItemsSource = context.Products
                    .Select(p => p.Category)
                    .Distinct()
                    .ToList();
            }

            grid.Children.Add(new TextBlock { Text = "Название:" });
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 0);
            grid.Children.Add(txtName);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 1);

            grid.Children.Add(new TextBlock { Text = "Категория:" });
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 2);
            grid.Children.Add(cmbCategory);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 3);

            grid.Children.Add(new TextBlock { Text = "Размер:" });
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 4);
            grid.Children.Add(txtSize);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 5);

            grid.Children.Add(new TextBlock { Text = "Цена:" });
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 6);
            grid.Children.Add(txtPrice);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 7);

            grid.Children.Add(new TextBlock { Text = "В наличии:" });
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 8);
            grid.Children.Add(txtStock);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 9);

            StackPanel buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            Button btnSave = new Button { Content = "Сохранить", Width = 100, Height = 30, Margin = new Thickness(0, 0, 10, 0) };
            Button btnCancel = new Button { Content = "Отмена", Width = 100, Height = 30 };
            buttons.Children.Add(btnSave);
            buttons.Children.Add(btnCancel);
            grid.Children.Add(buttons);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 10);

            addProductWindow.Content = grid;
            btnCancel.Click += (s, e) => addProductWindow.Close();

            btnSave.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtName.Text))
                {
                    MessageBox.Show("Введите название товара", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (!decimal.TryParse(txtPrice.Text, out decimal price))
                {
                    MessageBox.Show("Введите корректную цену", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (!int.TryParse(txtStock.Text, out int stock))
                {
                    MessageBox.Show("Введите корректное количество", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                using (var context = new ClothingShopContext())
                {
                    context.Products.Add(new Product
                    {
                        Name = txtName.Text,
                        Category = cmbCategory.SelectedItem?.ToString() ?? "Без категории",
                        Size = txtSize.Text,
                        Price = price,
                        Stock = stock
                    });
                    context.SaveChanges();
                }
                addProductWindow.Close();
                LoadProducts();
                MessageBox.Show("Товар добавлен!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            };

            addProductWindow.ShowDialog();
        }

        private void EditProduct_Click(object sender, RoutedEventArgs e)
        {
            if (dgProducts.SelectedItem is Product product)
            {
                Window editProductWindow = new Window
                {
                    Title = "Редактирование товара",
                    Width = 400,
                    Height = 500,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    ResizeMode = ResizeMode.NoResize
                };

                Grid grid = new Grid();
                grid.Margin = new Thickness(20);

                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

                TextBox txtName = new TextBox { Text = product.Name, Margin = new Thickness(0, 0, 0, 10) };
                ComboBox cmbCategory = new ComboBox { Margin = new Thickness(0, 0, 0, 10) };
                TextBox txtSize = new TextBox { Text = product.Size, Margin = new Thickness(0, 0, 0, 10) };
                TextBox txtPrice = new TextBox { Text = product.Price.ToString(), Margin = new Thickness(0, 0, 0, 10) };
                TextBox txtStock = new TextBox { Text = product.Stock.ToString(), Margin = new Thickness(0, 0, 0, 10) };

                using (var context = new ClothingShopContext())
                {
                    cmbCategory.ItemsSource = context.Products
                        .Select(p => p.Category)
                        .Distinct()
                        .ToList();
                }
                cmbCategory.SelectedItem = product.Category;

                grid.Children.Add(new TextBlock { Text = "Название:" });
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 0);
                grid.Children.Add(txtName);
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 1);

                grid.Children.Add(new TextBlock { Text = "Категория:" });
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 2);
                grid.Children.Add(cmbCategory);
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 3);

                grid.Children.Add(new TextBlock { Text = "Размер:" });
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 4);
                grid.Children.Add(txtSize);
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 5);

                grid.Children.Add(new TextBlock { Text = "Цена:" });
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 6);
                grid.Children.Add(txtPrice);
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 7);

                grid.Children.Add(new TextBlock { Text = "В наличии:" });
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 8);
                grid.Children.Add(txtStock);
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 9);

                StackPanel buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
                Button btnSave = new Button { Content = "Сохранить", Width = 100, Height = 30, Margin = new Thickness(0, 0, 10, 0) };
                Button btnCancel = new Button { Content = "Отмена", Width = 100, Height = 30 };
                buttons.Children.Add(btnSave);
                buttons.Children.Add(btnCancel);
                grid.Children.Add(buttons);
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 10);

                editProductWindow.Content = grid;
                btnCancel.Click += (s, e) => editProductWindow.Close();

                btnSave.Click += (s, e) =>
                {
                    if (string.IsNullOrWhiteSpace(txtName.Text))
                    {
                        MessageBox.Show("Введите название товара", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    if (!decimal.TryParse(txtPrice.Text, out decimal price))
                    {
                        MessageBox.Show("Введите корректную цену", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    if (!int.TryParse(txtStock.Text, out int stock))
                    {
                        MessageBox.Show("Введите корректное количество", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    product.Name = txtName.Text;
                    product.Category = cmbCategory.SelectedItem?.ToString() ?? "Без категории";
                    product.Size = txtSize.Text;
                    product.Price = price;
                    product.Stock = stock;

                    using (var context = new ClothingShopContext())
                    {
                        context.Products.Update(product);
                        context.SaveChanges();
                    }
                    editProductWindow.Close();
                    LoadProducts();
                    MessageBox.Show("Товар обновлён!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                };

                editProductWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Выберите товар для редактирования", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (dgProducts.SelectedItem is Product product)
            {
                var result = MessageBox.Show($"Удалить товар '{product.Name}'?",
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    using (var context = new ClothingShopContext())
                    {
                        var orderItems = context.OrderItems.Where(oi => oi.ProductId == product.Id);
                        context.OrderItems.RemoveRange(orderItems);
                        context.Products.Remove(product);
                        context.SaveChanges();
                    }
                    LoadProducts();
                    MessageBox.Show("Товар удалён!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Выберите товар для удаления", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ManageCategories_Click(object sender, RoutedEventArgs e)
        {
            Window categoriesWindow = new Window
            {
                Title = "Управление категориями",
                Width = 400,
                Height = 400,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize
            };

            Grid grid = new Grid();
            grid.Margin = new Thickness(20);
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            TextBox txtNewCategory = new TextBox { Margin = new Thickness(0, 0, 0, 10) };
            Button btnAddCategory = new Button { Content = "➕ Добавить категорию", Width = 150, Height = 30 };

            using (var context = new ClothingShopContext())
            {
                var categories = context.Products
                    .Select(p => p.Category)
                    .Distinct()
                    .ToList();
                ListBox lbCategories = new ListBox { ItemsSource = categories, Height = 200 };
                Grid.SetRow(lbCategories, 3);
                grid.Children.Add(lbCategories);
            }

            grid.Children.Add(new TextBlock { Text = "Новая категория:" });
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 0);
            grid.Children.Add(txtNewCategory);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 1);
            grid.Children.Add(btnAddCategory);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 2);

            categoriesWindow.Content = grid;
            btnAddCategory.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtNewCategory.Text))
                {
                    MessageBox.Show("Введите название категории", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                using (var context = new ClothingShopContext())
                {
                    context.Products.Add(new Product
                    {
                        Name = "Временный товар",
                        Category = txtNewCategory.Text,
                        Size = "M",
                        Price = 0,
                        Stock = 0
                    });
                    context.SaveChanges();
                }
                MessageBox.Show("Категория добавлена!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                categoriesWindow.Close();
            };

            categoriesWindow.ShowDialog();
        }

        private void LoadUsers()
        {
            using (var context = new ClothingShopContext())
            {
                dgUsers.ItemsSource = context.Users.ToList();
            }
        }

        private void Admin_Users_Click(object sender, RoutedEventArgs e)
        {
            ShowUsers();
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            Window addUserWindow = new Window
            {
                Title = "Добавление пользователя",
                Width = 400,
                Height = 300,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize
            };

            Grid grid = new Grid();
            grid.Margin = new Thickness(20);
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            TextBox txtUsername = new TextBox { Margin = new Thickness(0, 0, 0, 10) };
            TextBox txtPassword = new TextBox { Margin = new Thickness(0, 0, 0, 10) };
            TextBox txtEmail = new TextBox { Margin = new Thickness(0, 0, 0, 10) };
            ComboBox cmbRole = new ComboBox { Margin = new Thickness(0, 0, 0, 10) };
            cmbRole.ItemsSource = new[] { "user", "admin" };

            grid.Children.Add(new TextBlock { Text = "Логин:" });
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 0);
            grid.Children.Add(txtUsername);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 1);

            grid.Children.Add(new TextBlock { Text = "Пароль:" });
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 2);
            grid.Children.Add(txtPassword);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 3);

            grid.Children.Add(new TextBlock { Text = "Email:" });
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 4);
            grid.Children.Add(txtEmail);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 5);

            grid.Children.Add(new TextBlock { Text = "Роль:" });
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 6);
            grid.Children.Add(cmbRole);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 7);

            StackPanel buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            Button btnSave = new Button { Content = "Сохранить", Width = 100, Height = 30, Margin = new Thickness(0, 0, 10, 0) };
            Button btnCancel = new Button { Content = "Отмена", Width = 100, Height = 30 };
            buttons.Children.Add(btnSave);
            buttons.Children.Add(btnCancel);
            grid.Children.Add(buttons);
            Grid.SetRow(grid.Children[grid.Children.Count - 1], 8);

            addUserWindow.Content = grid;
            btnCancel.Click += (s, e) => addUserWindow.Close();

            btnSave.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtUsername.Text))
                {
                    MessageBox.Show("Введите логин", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtPassword.Text))
                {
                    MessageBox.Show("Введите пароль", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                using (var context = new ClothingShopContext())
                {
                    if (context.Users.Any(u => u.Username == txtUsername.Text))
                    {
                        MessageBox.Show("Пользователь с таким логином уже существует", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    context.Users.Add(new User
                    {
                        Username = txtUsername.Text,
                        Password = txtPassword.Text,
                        Email = txtEmail.Text,
                        Role = cmbRole.SelectedItem?.ToString() ?? "user"
                    });
                    context.SaveChanges();
                }
                addUserWindow.Close();
                LoadUsers();
                MessageBox.Show("Пользователь добавлен!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            };

            addUserWindow.ShowDialog();
        }

        private void EditUserRole_Click(object sender, RoutedEventArgs e)
        {
            if (dgUsers.SelectedItem is User user)
            {
                Window roleWindow = new Window
                {
                    Title = "Изменить роль пользователя",
                    Width = 300,
                    Height = 200,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    ResizeMode = ResizeMode.NoResize
                };

                Grid grid = new Grid();
                grid.Margin = new Thickness(20);
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

                ComboBox cmbRole = new ComboBox { Margin = new Thickness(0, 0, 0, 10) };
                cmbRole.ItemsSource = new[] { "user", "admin" };
                cmbRole.SelectedItem = user.Role;

                StackPanel buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
                Button btnSave = new Button { Content = "Сохранить", Width = 80, Height = 30, Margin = new Thickness(0, 0, 10, 0) };
                Button btnCancel = new Button { Content = "Отмена", Width = 80, Height = 30 };
                buttons.Children.Add(btnSave);
                buttons.Children.Add(btnCancel);

                grid.Children.Add(cmbRole);
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 0);
                grid.Children.Add(buttons);
                Grid.SetRow(grid.Children[grid.Children.Count - 1], 1);

                roleWindow.Content = grid;
                btnCancel.Click += (s, e) => roleWindow.Close();

                btnSave.Click += (s, e) =>
                {
                    user.Role = cmbRole.SelectedItem?.ToString() ?? "user";
                    using (var context = new ClothingShopContext())
                    {
                        context.Users.Update(user);
                        context.SaveChanges();
                    }
                    roleWindow.Close();
                    LoadUsers();
                    MessageBox.Show("Роль пользователя обновлена!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                };

                roleWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Выберите пользователя для редактирования", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DeleteUser_Click(object sender, RoutedEventArgs e)
        {
            if (dgUsers.SelectedItem is User user)
            {
                var result = MessageBox.Show($"Удалить пользователя '{user.Username}'?",
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    using (var context = new ClothingShopContext())
                    {
                        context.Users.Remove(user);
                        context.SaveChanges();
                    }
                    LoadUsers();
                    MessageBox.Show("Пользователь удалён!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Выберите пользователя для удаления", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Вы уверены, что хотите выйти?",
                "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                LoginWindow loginWindow = new LoginWindow();
                loginWindow.Show();
                this.Close();
            }
        }
    }
}