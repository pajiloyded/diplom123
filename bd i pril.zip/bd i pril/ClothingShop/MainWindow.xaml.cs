﻿using ClothingShopWPF;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using бд.Models;

namespace ClothingShop
{
    public partial class MainWindow : Window
    {
        private int userId;
        private string userRole;

        public MainWindow(int userId, string userRole)
        {
            InitializeComponent();
            this.userId = userId;
            this.userRole = userRole;
            LoadProducts();
            LoadCategories();
        }

        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoadProducts()
        {
            using (var context = new ClothingShopContext())
            {
                var products = context.Products.ToList();
                lvProducts.ItemsSource = products;

                if (products.Count == 0)
                {
                    MessageBox.Show("В базе данных нет товаров.", "Внимание",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        private void LoadCategories()
        {
            using (var context = new ClothingShopContext())
            {
                var categories = context.Products
                    .Select(p => p.Category)
                    .Distinct()
                    .ToList();
                cmbCategory.ItemsSource = categories;
                cmbCategory.SelectedIndex = -1;
            }
        }

        private void Filter_Changed(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void ApplyFilters()
        {
            string search = txtSearch.Text.ToLower();
            string category = cmbCategory.SelectedItem?.ToString();

            using (var context = new ClothingShopContext())
            {
                var query = context.Products.AsQueryable();

                if (!string.IsNullOrEmpty(search) && search != "поиск товаров...")
                    query = query.Where(p => p.Name.ToLower().Contains(search));
                if (!string.IsNullOrEmpty(category))
                    query = query.Where(p => p.Category == category);

                lvProducts.ItemsSource = query.ToList();
            }
        }

        private void AddToCart_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var product = button?.DataContext as Product;

            if (product != null)
            {
                using (var context = new ClothingShopContext())
                {
                    var cartItem = context.CartItems
                        .FirstOrDefault(c => c.UserId == userId && c.ProductId == product.Id);

                    if (cartItem != null)
                    {
                        cartItem.Quantity++;
                    }
                    else
                    {
                        context.CartItems.Add(new CartItem
                        {
                            UserId = userId,
                            ProductId = product.Id,
                            Quantity = 1,
                            Price = product.Price
                        });
                    }
                    context.SaveChanges();
                }
                MessageBox.Show($"{product.Name} добавлен в корзину!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void OpenCart_Click(object sender, RoutedEventArgs e)
        {
            CartWindow cartWindow = new CartWindow(userId);
            cartWindow.Show();
        }

        private void OpenProfile_Click(object sender, RoutedEventArgs e)
        {
            ProfileWindow profileWindow = new ProfileWindow(userId);
            profileWindow.Show();
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Вы уверены, что хотите выйти?",
                "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                LoginWindow loginWindow = new LoginWindow();
                loginWindow.Show();
                this.Close();
            }
        }

       
    }
}