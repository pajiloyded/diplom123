﻿using ClothingShop;
using System;
using System.Linq;
using System.Windows;
using бд.Models;

namespace ClothingShopWPF
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text;
            string password = txtPassword.Password;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                lblError.Text = "Введите логин и пароль";
                lblError.Visibility = Visibility.Visible;
                return;
            }

            try
            {
                using (var context = new ClothingShopContext())
                {
                    var user = context.Users
                        .FirstOrDefault(u => u.Username == login && u.Password == password);

                    if (user != null)
                    {
                        if (user.Role == "admin")
                        {
                   
                            AdminMainPanel adminWindow = new AdminMainPanel(user.Id, user.Role);
                            adminWindow.Show();
                        }
                        else
                        {
                            MainWindow mainWindow = new MainWindow(user.Id, user.Role);
                            mainWindow.Show();
                        }
                        this.Close();
                    }
                    else
                    {
                        lblError.Text = "Неверный логин или пароль";
                        lblError.Visibility = Visibility.Visible;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения к БД: " + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RegisterButton_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            RegisterWindow registerWindow = new RegisterWindow();
            registerWindow.Show();
            this.Close();
        }
    }
}