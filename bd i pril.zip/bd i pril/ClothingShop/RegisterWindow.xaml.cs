﻿using System;
using System.Linq;
using System.Windows;
using бд.Models;

namespace ClothingShopWPF
{
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text;
            string password = txtPassword.Password;
            string confirm = txtConfirmPassword.Password;
            string email = txtEmail.Text;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                lblError.Text = "Заполните логин и пароль";
                lblError.Visibility = Visibility.Visible;
                return;
            }

            if (password != confirm)
            {
                lblError.Text = "Пароли не совпадают";
                lblError.Visibility = Visibility.Visible;
                return;
            }

            using (var context = new ClothingShopContext())
            {
                bool userExists = context.Users.Any(u => u.Username == login);
                if (userExists)
                {
                    lblError.Text = "Логин уже занят";
                    lblError.Visibility = Visibility.Visible;
                    return;
                }

               
                var newUser = new User
                {
                    Username = login,
                    Password = password,
                    Email = email,
                    Role = "Client"
                };

                context.Users.Add(newUser);
                context.SaveChanges();

                MessageBox.Show("Регистрация успешна! Войдите в систему.", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                LoginWindow loginWindow = new LoginWindow();
                loginWindow.Show();
                this.Close();
            }
        }
    }
}