﻿using System.Linq;
using System.Windows;
using бд.Models;

namespace ClothingShop
{
    public partial class CartWindow : Window
    {
        private int userId;

        public CartWindow(int userId)
        {
            InitializeComponent();
            this.userId = userId;
            LoadCart();
        }

        private void LoadCart()
        {
            using (var context = new ClothingShopContext())
            {
                var cartItems = context.CartItems
                    .Where(c => c.UserId == userId)
                    .Select(c => new
                    {
                        c.Product.Name,
                        c.Price,
                        c.Quantity,
                        Total = c.Price * c.Quantity
                    })
                    .ToList();

                dgCart.ItemsSource = cartItems;
                decimal total = cartItems.Sum(c => c.Total);
                lblTotal.Text = $"Итого: {total:C}";
            }
        }

        private void CreateOrder_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new ClothingShopContext())
            {
                var cartItems = context.CartItems
                    .Where(c => c.UserId == userId)
                    .ToList();

                if (cartItems.Count == 0)
                {
                    MessageBox.Show("Корзина пуста", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                decimal total = cartItems.Sum(c => c.Price * c.Quantity);

                var order = new Order
                {
                    UserId = userId,
                    TotalAmount = total,
                    Status = "Новый"
                };
                context.Orders.Add(order);
                context.SaveChanges();

                foreach (var item in cartItems)
                {
                    context.OrderItems.Add(new OrderItem
                    {
                        OrderId = order.Id,
                        ProductId = item.ProductId,
                        Quantity = item.Quantity,
                        Price = item.Price
                    });

                    var product = context.Products.Find(item.ProductId);
                    if (product != null)
                    {
                        product.Stock -= item.Quantity;
                    }
                }

                context.CartItems.RemoveRange(cartItems);
                context.SaveChanges();

                MessageBox.Show("Заказ оформлен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadCart();
            }
        }

        private void ClearCart_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Очистить корзину?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                using (var context = new ClothingShopContext())
                {
                    var cartItems = context.CartItems.Where(c => c.UserId == userId);
                    context.CartItems.RemoveRange(cartItems);
                    context.SaveChanges();
                }
                LoadCart();
            }
        }
    }
}