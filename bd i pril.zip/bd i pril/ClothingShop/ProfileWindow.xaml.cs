﻿using System.Linq;
using System.Windows;
using бд.Models;

namespace ClothingShopWPF
{
    public partial class ProfileWindow : Window
    {
        private int userId;

        public ProfileWindow(int userId)
        {
            InitializeComponent();
            this.userId = userId;
            LoadUserData();
        }

        private void LoadUserData()
        {
            using (var context = new ClothingShopContext())
            {
                var user = context.Users.Find(userId);
                if (user != null)
                {
                    txtLogin.Text = user.Username;
                    txtEmail.Text = user.Email;
                }
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new ClothingShopContext())
            {
                var user = context.Users.Find(userId);
                if (user != null)
                {
                    user.Email = txtEmail.Text;
                    if (!string.IsNullOrWhiteSpace(txtPassword.Password))
                        user.Password = txtPassword.Password;
                    context.SaveChanges();
                    MessageBox.Show("Данные обновлены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        private void ViewOrders_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new ClothingShopContext())
            {
                var orders = context.Orders
                    .Where(o => o.UserId == userId)
                    .Select(o => new
                    {
                        o.Id,
                        o.OrderDate,
                        o.TotalAmount,
                        o.Status
                    })
                    .ToList();

                string orderText = "История заказов:\n\n";
                foreach (var order in orders)
                {
                    orderText += $"Заказ #{order.Id} от {order.OrderDate:dd.MM.yyyy}: {order.TotalAmount:C} - {order.Status}\n";
                }
                MessageBox.Show(orderText, "История заказов", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}